package com.snowsmp.wardenpet;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Warden;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public final class SnowWardenPet extends JavaPlugin implements Listener {
    private NamespacedKey petKey;
    private NamespacedKey ownerKey;
    private final Map<UUID, UUID> pets = new HashMap<>();
    private final Map<UUID, UUID> targets = new HashMap<>();
    private final Set<UUID> owners = new HashSet<>();
    private final Set<UUID> active = new HashSet<>();
    private BukkitTask task;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        petKey = new NamespacedKey(this, "warden_pet");
        ownerKey = new NamespacedKey(this, "warden_owner");
        loadState();
        Bukkit.getPluginManager().registerEvents(this, this);
        task = Bukkit.getScheduler().runTaskTimer(this, this::tickPets, 1L, 5L);
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        for (UUID petId : new ArrayList<>(pets.values())) {
            Entity e = Bukkit.getEntity(petId);
            if (e != null) e.remove();
        }
        saveState();
    }

    private void loadState() {
        owners.clear();
        active.clear();
        for (String s : getConfig().getStringList("owners")) {
            try { owners.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        }
        for (String s : getConfig().getStringList("active")) {
            try { active.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveState() {
        List<String> o = owners.stream().map(UUID::toString).toList();
        List<String> a = active.stream().map(UUID::toString).toList();
        getConfig().set("owners", o);
        getConfig().set("active", a);
        saveConfig();
    }

    private ItemStack petItem() {
        Material material = Material.matchMaterial(getConfig().getString("pet.item-material", "NETHER_STAR"));
        if (material == null) material = Material.NETHER_STAR;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', getConfig().getString("pet.name", "&5&lWarden Pet")));
        meta.setLore(List.of(org.bukkit.ChatColor.translateAlternateColorCodes('&', getConfig().getString("pet.item-lore", "&7Right-click to summon your Warden Pet."))));
        meta.getPersistentDataContainer().set(petKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isPetItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return false;
        Byte value = item.getItemMeta().getPersistentDataContainer().get(petKey, PersistentDataType.BYTE);
        return value != null && value == 1;
    }

    private Warden spawnPet(Player owner) {
        Warden warden = owner.getWorld().spawn(owner.getLocation().add(1.0, 0, 0), Warden.class);
        warden.setInvulnerable(true);
        warden.setAI(false);
        var scale = warden.getAttribute(Attribute.SCALE);
        if (scale != null) scale.setBaseValue(getConfig().getDouble("pet.scale", 0.3));
        PersistentDataContainer pdc = warden.getPersistentDataContainer();
        pdc.set(petKey, PersistentDataType.BYTE, (byte) 1);
        pdc.set(ownerKey, PersistentDataType.STRING, owner.getUniqueId().toString());
        pets.put(owner.getUniqueId(), warden.getUniqueId());
        return warden;
    }

    private Warden getPet(UUID ownerId) {
        UUID id = pets.get(ownerId);
        if (id == null) return null;
        Entity e = Bukkit.getEntity(id);
        if (!(e instanceof Warden w) || !w.isValid()) {
            pets.remove(ownerId);
            return null;
        }
        return w;
    }

    private UUID getOwner(Entity entity) {
        String s = entity.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (s == null) return null;
        try { return UUID.fromString(s); } catch (IllegalArgumentException e) { return null; }
    }

    private void summon(Player player) {
        if (!owners.contains(player.getUniqueId())) {
            player.sendMessage("§cYou don't own a Warden Pet.");
            return;
        }
        if (active.contains(player.getUniqueId())) {
            player.sendMessage("§cYour Warden Pet is already active.");
            return;
        }
        active.add(player.getUniqueId());
        spawnPet(player);
        saveState();
        player.sendMessage("§5§lWARDEN PET §8» §aYour Warden Pet has been summoned.");
    }

    private void dismiss(Player player, boolean message) {
        active.remove(player.getUniqueId());
        targets.remove(player.getUniqueId());
        Warden pet = getPet(player.getUniqueId());
        if (pet != null) pet.remove();
        pets.remove(player.getUniqueId());
        saveState();
        if (message) player.sendMessage("§5§lWARDEN PET §8» §cYour Warden Pet has been dismissed.");
    }

    private void tickPets() {
        for (UUID ownerId : new ArrayList<>(active)) {
            Player owner = Bukkit.getPlayer(ownerId);
            if (owner == null || !owner.isOnline()) continue;
            Warden pet = getPet(ownerId);
            if (pet == null) pet = spawnPet(owner);

            UUID targetId = targets.get(ownerId);
            LivingEntity target = targetId == null ? null : livingEntity(targetId);

            if (target != null && !target.isDead() && target.getWorld().equals(owner.getWorld())) {
                if (target.getLocation().distanceSquared(owner.getLocation()) <= 64 * 64) {
                    pet.setAI(true);
                    pet.setTarget(target);
                    continue;
                }
            }

            targets.remove(ownerId);
            pet.setTarget(null);
            pet.setAI(false);

            double follow = getConfig().getDouble("pet.follow-distance", 6.0);
            double teleport = getConfig().getDouble("pet.teleport-distance", 18.0);
            double distance = pet.getLocation().distance(owner.getLocation());

            if (distance > teleport) {
                pet.teleport(owner.getLocation().add(1.0, 0, 0));
            } else if (distance > follow) {
                Vector direction = owner.getLocation().toVector().subtract(pet.getLocation().toVector()).normalize();
                Location next = owner.getLocation().clone().subtract(direction.multiply(2.0));
                next.setY(owner.getLocation().getY());
                pet.teleport(next);
            }
        }
    }

    private LivingEntity livingEntity(UUID id) {
        Entity e = Bukkit.getEntity(id);
        return e instanceof LivingEntity living ? living : null;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!isPetItem(event.getItem())) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!owners.contains(player.getUniqueId())) return;
        if (active.contains(player.getUniqueId())) return;
        ItemStack item = event.getItem();
        if (item != null) {
            item.setAmount(item.getAmount() - 1);
            player.getInventory().setItemInMainHand(item);
        }
        summon(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTarget(EntityTargetEvent event) {
        if (!(event.getEntity() instanceof Warden warden)) return;
        UUID ownerId = getOwner(warden);
        if (ownerId == null) return;
        Entity target = event.getTarget();
        if (!(target instanceof LivingEntity living) || target instanceof Player) {
            event.setCancelled(true);
            warden.setTarget(null);
            return;
        }
        UUID wanted = targets.get(ownerId);
        if (wanted == null || !wanted.equals(living.getUniqueId())) {
            event.setCancelled(true);
            warden.setTarget(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Warden warden) {
            UUID ownerId = getOwner(warden);
            if (ownerId != null) {
                if (event.getEntity() instanceof Player) {
                    event.setCancelled(true);
                    warden.setTarget(null);
                    warden.setAI(false);
                    targets.remove(ownerId);
                    return;
                }
                event.setDamage(getConfig().getDouble("pet.damage", 1.0));
            }
        }

        Player attacker = null;
        if (event.getDamager() instanceof Player player) attacker = player;
        else if (event.getDamager() instanceof Projectile projectile && projectile.getShooter() instanceof Player player) attacker = player;
        if (attacker == null || !owners.contains(attacker.getUniqueId())) return;
        if (!(event.getEntity() instanceof LivingEntity target) || target instanceof Player) return;
        Warden pet = getPet(attacker.getUniqueId());
        if (pet == null || target.equals(pet)) return;
        targets.put(attacker.getUniqueId(), target.getUniqueId());
        pet.setAI(true);
        pet.setTarget(target);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Warden pet = getPet(player.getUniqueId());
        if (pet != null) pet.remove();
        pets.remove(player.getUniqueId());
        targets.remove(player.getUniqueId());
        saveState();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!owners.contains(player.getUniqueId()) || !active.contains(player.getUniqueId())) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline() && active.contains(player.getUniqueId()) && getPet(player.getUniqueId()) == null) spawnPet(player);
        }, 10L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Warden pet = getPet(event.getEntity().getUniqueId());
        if (pet != null) pet.remove();
        pets.remove(event.getEntity().getUniqueId());
        targets.remove(event.getEntity().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("wardenpet")) {
            if (!(sender instanceof Player player)) return true;
            if (!owners.contains(player.getUniqueId())) {
                player.sendMessage("§cYou don't own a Warden Pet.");
                return true;
            }
            if (active.contains(player.getUniqueId())) dismiss(player, true);
            else summon(player);
            return true;
        }

        if (command.getName().equalsIgnoreCase("givewardenpet")) {
            if (!(sender instanceof Player) || !sender.hasPermission("wardenpet.give")) return true;
            if (args.length != 1) return false;
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage("§cPlayer not found or offline.");
                return true;
            }
            owners.add(target.getUniqueId());
            target.getInventory().addItem(petItem());
            sender.sendMessage("§aGave Warden Pet to " + target.getName() + ".");
            target.sendMessage("§5§lWARDEN PET §8» §fYou received a Warden Pet!");
            target.sendMessage("§7Right-click the Nether Star to summon it.");
            saveState();
            return true;
        }

        if (command.getName().equalsIgnoreCase("removewardenpet")) {
            if (!(sender instanceof Player) || !sender.hasPermission("wardenpet.admin")) return true;
            if (args.length != 1) return false;
            Player target = Bukkit.getPlayerExact(args[0]);
            UUID id = target != null ? target.getUniqueId() : null;
            if (id == null) {
                try { id = UUID.fromString(args[0]); } catch (IllegalArgumentException ignored) {}
            }
            if (id == null || !owners.contains(id)) {
                sender.sendMessage("§cPlayer not found or they don't own a Warden Pet.");
                return true;
            }
            Warden pet = getPet(id);
            if (pet != null) pet.remove();
            pets.remove(id);
            targets.remove(id);
            owners.remove(id);
            active.remove(id);
            saveState();
            sender.sendMessage("§cRemoved Warden Pet ownership.");
            if (target != null) target.sendMessage("§cYour Warden Pet ownership was removed.");
            return true;
        }
        return false;
    }
}
